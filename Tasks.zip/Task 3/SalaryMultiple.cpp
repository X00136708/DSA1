#include <iostream>
#include <fstream>

using namespace std;
int main() {
	ifstream myFile;
	ofstream myFiles;
	myFile.open("salaryMultiple.txt");
	myFiles.open("newSalaryMultiple.txt");
	double salary;
	char name[50];
	int totalEmployees=1;
	double backPay = .076;

	if (myFile.is_open()) {
		while (!myFile.eof()) {
			myFile >> name >> salary;
			double regMonthly = salary / 12;
			double halfSalary = salary / 2;
			double half = salary / 2;

			halfSalary += (halfSalary * backPay);
			salary = half + halfSalary;
			double monthly = salary / 12;

			cout << "New details writen to newSalary.txt";
			myFiles << "New salary for: " << name << ": " << salary << endl << "New monthly pay (back pay): " << monthly << endl << "Regular monthly pay (after back-pay): " << regMonthly << endl << endl << "Total employees: " << totalEmployees;
			totalEmployees++;

		}
	}
	myFile.close();
	myFiles.close();
	return 0;
}
// Didn't have time to make them all have different files, i'm working on it after class though.