#include <iostream>
#include <fstream>

using namespace std;
int main() {
	ifstream myFile;
	ofstream myFiles;
	myFile.open("salary.txt");
	myFiles.open("newSalary.txt");
	double salary;
	double backPay = .076;
	
	if (myFile.is_open()) {
		while (!myFile.eof()) {
			myFile >> salary;
			double regMonthly = salary / 12;
			double halfSalary = salary / 2;
			double half = salary/2;

			halfSalary += (halfSalary * backPay);
			salary = half+halfSalary;
			double monthly = salary / 12;
			
			cout << "New details writen to newSalary.txt";
			myFiles << "New salary: " << salary << endl << "New monthly pay (back pay): " << monthly << endl << "Regular monthly pay (after back-pay): " << regMonthly;
			
			
		}
	}
	myFile.close();
	myFiles.close();
	return 0;
}
//help about taking in values from files - > http://www.cplusplus.com/forum/beginner/8388/
//I couldn't write the new values to the same file without getting negative numbers as the file was already overriden by the time it had to take the new values in.
