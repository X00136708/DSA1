#include <iostream>
#include <stdio.h>
using namespace std;

int main() {
	
		int hours;
		double rate;
		double grossPay = 0;
		char result;
		
		cout << "Enter your hours worked and rate" << endl;
		cin >> hours >> rate;
		if (hours < 40) {
			grossPay = hours * rate;
		}
		else if (hours > 40) {
			int hoursAfter = hours - 40;
			grossPay = 40 * rate;
			grossPay += hoursAfter * (rate*1.5);
		}
		cout << "Gross pay: " << grossPay << endl;
		cout << "Would you like to calculate grossPay again?";
		cin >> result;
	
		while (result == 'Y' || result == 'y') {
			cout << "Enter your hours worked and rate" << endl;
			cin >> hours >> rate;
			if (hours < 40) {
				grossPay = hours * rate;
			}
			else if (hours > 40) {
				int hoursAfter = hours - 40;
				grossPay = 40 * rate;
				grossPay += hoursAfter * (rate*1.5);
			}
			cout << "Gross pay: " << grossPay << endl;
			cout << "Would you like to calculate grossPay again?" << endl;
		cin >> result;
		}
	return 0;
}
//I copied and pasted my own code inside the while loop, didn't get it from anywhere else